function validateform()
		{  
			var name=document.addcontact.name.value;
			var mobilenumber=document.addcontact.mobilenumber.value;
			var email=document.addcontact.email.value;

			var len=mobilenumber.length;
			var atposition=email.indexOf("@");  
			var dotposition=email.lastIndexOf(".");  
			console.log(name);
			if (name==null || name==""){  
				  alert("Name can't be blank");  
				  return false;  
			}
			else if (mobilenumber==null || mobilenumber==""){  
				  alert("mobilenumber can't be blank");  
				  return false;  
			}
			else if(len!=10)
			{
			alert("plz enter valid mobile no");
			return false;
			}
			

			else if (atposition<1 || dotposition<atposition+2 || dotposition+2>=email.length){  
//			  alert("Please enter a valid e-mail address \n atpostion:"+atposition+"\n dotposition:"+dotposition);  
			alert("Please Enter Valid e-mail address");
				return false;  
			  } 
			
			
			
		}