package com.contact.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.contact.beans.ContactBeans;
import com.contact.dao.contactdao;

/**
 * Servlet implementation class viewcontact
 */
@WebServlet("/viewcontact")
public class viewcontact extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public viewcontact() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		 pw.println("<a href='addnewcontact.html'>Add New Contact</a>");  
	        pw.println("<h1>Contact List</h1>"); 
	        pw.write("<link href='./CSS/bootstrap.min.css' rel='stylesheet' >");
		contactdao dao=new contactdao();
		
		List<ContactBeans> list=new ArrayList<ContactBeans>();
		
		try {
		List<ContactBeans> detailsresult=dao.getContactDetails();
		
		pw.write("<table class='table table-hover table-dark table-striped table-bordered'>");
		pw.write("<thead class='thead-light'><tr><th>ID</th><th>Name</th><th>Phone Number</th><th>Email</th><th>Edit</th><th>Delete</th></tr></thead>");
		pw.write("<tbody>");
		
		for(ContactBeans c:detailsresult)
		pw.write("<tr><td>"+c.getId()+"</td><td>"+c.getName()+"</td><td>"+c.getMobilenumber()+"</td><td>"+c.getEmail()+"</td><td><a href='EditServlet?id="+c.getId()+"' >Edit</a></td><td><a href='DeleteServlet?id="+c.getId()+"'>Delete</a></td></td>");
		pw.write("</tbody></table>");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
