package com.contact.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.contact.beans.ContactBeans;
import com.contact.dao.contactdao;

/**
 * Servlet implementation class EditServlet
 */
@WebServlet("/EditServlet")
public class EditServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		int id=Integer.parseInt(request.getParameter("id"));
		contactdao dao=new contactdao();
		pw.write("<script src='./CSS/validation.js'></script>" );
		pw.write("<link href='./CSS/bootstrap.min.css' rel='stylesheet' type='text/css'>" );
		ContactBeans beans = null;
		try {
			 beans=dao.DisplayText(id);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		pw.write("<h2 style='text-align:center'>Update Details</h2>");
		pw.write("<div class='row'></div><br><br>");
		pw.write("<div class='row'>");
		pw.write("<div class='col-sm-4'></div>");
		pw.write("<div class='col-sm-4'>");
		pw.write("<div class='container'>");
		pw.write("<div class='form-group'>");
		pw.write("<form  name='addcontact' onsubmit='return validateform()' action='UpdateServlet'>");
//		pw.write("<script src='./CSS/script.js'></script>" );
		pw.write("<table class='table table-hover table-dark table-strited table-bordered'>");
		pw.print("<tr><td></td><td><input type='hidden' name='id' class='form-control' value='"+beans.getId()+"'/></td></tr>");  
        pw.print("<tr><td>Name:</td><td><input type='text' name='name' class='form-control' value='"+beans.getName()+"'/></td></tr>");  
        pw.print("<tr><td>Mobile Number:</td><td><input type='text' name='mobilenumber' class='form-control' value='"+beans.getMobilenumber()+"'/></td></tr>");  
        pw.print("<tr><td>Email:</td><td><input type='text' name='email' class='form-control' value='"+beans.getEmail()+"'/></td></tr>");  
        pw.print("<tr><td colspan='2'><input type='submit' value='Edit & Save' class='btn btn-primary form-control'/></td></tr>"); 
        pw.print("<tr><td colspan='2'><a href='Welcome.html' class='btn btn-primary form-control'>Cancel</a></td></tr>"); 

        pw.write("</table>");
		pw.write("</form>");
		pw.write("</div>");
		pw.write("</div>");
		pw.write("</div>");
		pw.write("</div>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
