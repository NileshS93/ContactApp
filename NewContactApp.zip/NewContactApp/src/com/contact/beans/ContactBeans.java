package com.contact.beans;

public class ContactBeans
{
	private int id;
	private String name;
	private String mobilenumber;
	private String email;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobilenumber() {
		return mobilenumber;
	}
	public void setMobilenumber(String mobilenumber) {
		this.mobilenumber = mobilenumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "ContactBeans [id=" + id + ", name=" + name + ", mobilenumber=" + mobilenumber + ", email=" + email
				+ "]";
	}
	
	

}
