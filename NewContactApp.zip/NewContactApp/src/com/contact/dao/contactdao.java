package com.contact.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.contact.beans.ContactBeans;


public class contactdao 
{
	private static String DB_URL="jdbc:mysql://localhost:3306/ContactApp";
	private static String username="root";
	private static String password="root";
	
	public static Connection getConnection() throws SQLException
	{
		Connection con=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(DB_URL,username,password);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		return con;
	}
	
	public int addnewcontact(ContactBeans beans) throws SQLException
	{
		String query="INSERT INTO contact_list (c_name,mobile_no,email) VALUES(?,?,?)";
		PreparedStatement pst=getConnection().prepareStatement(query);
		pst.setString(1, beans.getName());
		pst.setString(2, beans.getMobilenumber());
		pst.setString(3, beans.getEmail());
		
		int i=pst.executeUpdate();
		return i;
	}
	
	public List<ContactBeans> getContactDetails() throws SQLException
	{
		List<ContactBeans> list=new ArrayList<ContactBeans>();
			String query="SELECT * FROM contact_list";
			PreparedStatement pst=getConnection().prepareStatement(query);
		ResultSet rs=pst.executeQuery();
		
		while(rs.next())
		{
			ContactBeans beans=new ContactBeans();
			beans.setId(rs.getInt(1));
			beans.setName(rs.getString(2));
			beans.setMobilenumber(rs.getString(3));
			beans.setEmail(rs.getString(4));
			list.add(beans);
		}
		
		return list;
	}
	
	
	public int DeleteRecord(int id) throws SQLException
	{
		String query="delete from contact_list where id=?";
		PreparedStatement pst=getConnection().prepareStatement(query);	
		pst.setInt(1, id);
	int i=pst.executeUpdate();
	return i;
		
	}
	
	public int UpdateRecord(ContactBeans beans) throws SQLException
	{
		int i=0;
		String query="update contact_list set c_name=?,mobile_no=?,email=? where id=?";
		PreparedStatement pst=getConnection().prepareStatement(query);
		pst.setString(1, beans.getName());
		pst.setString(2, beans.getMobilenumber());
		pst.setString(3, beans.getEmail());
		pst.setInt(4, beans.getId());
		
		i=pst.executeUpdate();
		return i;
	}
	
	public ContactBeans DisplayText(int id) throws SQLException
	{
		ContactBeans beans=new ContactBeans();
		String query="SELECT * FROM contact_list WHERE id=? ";
		PreparedStatement pst=getConnection().prepareStatement(query);
		pst.setInt(1, id);
	ResultSet rs=pst.executeQuery();
	while(rs.next())
	{
		beans.setId(rs.getInt(1));
		beans.setName(rs.getString(2));
		beans.setMobilenumber(rs.getString(3));
		beans.setEmail(rs.getString(4));
	}
		
		
		
		return beans;

	}
	

}
